  
	</div><!-- / content -->
  <?php get_sidebar(); ?>

</div>
<!-- / wrapper -->

<footer id="footer">
	<div class="inner">
  <!--<p id="footerLogo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php cTpl_rwd005_orange_print_Logo();?></a></p>-->
	<?php $footerNav = wp_nav_menu( array( 'container' => '', 'items_wrap' => '<ul>%3$s</ul>','theme_location'=>'footer') );?>
	<p id="copyright">Copyright &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?> All rights Reserved.</p>
  </div>
</footer>
	<!-- / footer -->

<?php wp_footer(); ?>
</body>
</html>