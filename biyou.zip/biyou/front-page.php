<?php get_header();
$header_image = get_header_image();
if ($header_image):?>
  <div id="mainImg"><img src="<?php header_image(); ?>" width="<?php echo HEADER_IMAGE_WIDTH; ?>" height="<?php echo HEADER_IMAGE_HEIGHT; ?>" alt="<?php bloginfo( 'description' ); ?>"></div><?php endif;?>

<div id="wrapper">
	<div id="content">
  	<?php cTpl_rwd005_orange_topProduct(); ?>
  
  	<section>
    <?php if ( have_posts()) : the_post(); ?>
  	<article id="post-<?php the_ID(); ?>" class="content">
		  <header> 	
      	<h2 class="title first"><span><?php the_title(); ?></span></h2>     
    	</header>
      <?php the_content();?>
    </article>
		<?php endif; ?>
    
    
		</section>
<?php get_footer(); ?>