<?php
/* This theme doesn't suport a comment function */
?>